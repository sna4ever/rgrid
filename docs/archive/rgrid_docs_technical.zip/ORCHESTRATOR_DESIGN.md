# RGrid – Orchestrator Design (Condensed)

Responsibilities:
- Watch queue depth per project.
- Decide desired node counts.
- Call Hetzner API to create/destroy CX22 nodes.
- Track node states (active, draining, terminated).
- Monitor heartbeats and requeue jobs from dead nodes.
- Enforce timeouts and retry policies.
- Aggregate cost metrics per project/day.

Scaling rule (simplified):

```text
desired_nodes = ceil(queued_jobs / (vCPUs_per_node))
```

For CX22 with 2 vCPUs and 1 job per vCPU, each node can handle 2 concurrent jobs.
