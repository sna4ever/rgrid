# RGrid – Architecture Summary

RGrid is a multi-tenant, API-driven compute platform that:
- authenticates via Clerk,
- stores state in Postgres,
- runs jobs in Docker on Hetzner CX22 nodes,
- uses MinIO for artifacts,
- orchestrates capacity via an async control-plane service.

Core invariants:
- Jobs are fully described via JobSpec.
- Containers are ephemeral and strongly isolated.
- Worker nodes are disposable and short-lived.
- Input and output files always move through presigned URLs.
- All observable state (jobs, executions, logs, artifacts, nodes, costs) lives in Postgres + MinIO.
