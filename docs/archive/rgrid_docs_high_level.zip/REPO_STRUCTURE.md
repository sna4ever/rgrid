# RGrid – Repo Structure (Condensed)

Recommended monorepo layout:

- `docs/` – all .md docs (this bundle).
- `api/` – FastAPI backend.
- `orchestrator/` – autoscaler and node lifecycle daemon.
- `runner/` – worker agent.
- `console/` – Next.js front-end.
- `cli/` – Python-based `rgrid` CLI tool.
- `infra/` – Terraform, cloud-init templates, Dockerfiles.
- `tests/` – unit and integration tests.
