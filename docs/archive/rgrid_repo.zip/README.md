# RGrid

This repository contains the beginnings of the RGrid platform:

- **docs/**: architecture and design docs.
- **api/**: FastAPI backend (to be implemented).
- **orchestrator/**: autoscaling & node lifecycle (to be implemented).
- **runner/**: worker agent (to be implemented).
- **console/**: Next.js UI (to be implemented).
- **cli/**: rgrid CLI (to be implemented).
- **infra/**: infrastructure as code for Hetzner/MinIO/Postgres.
